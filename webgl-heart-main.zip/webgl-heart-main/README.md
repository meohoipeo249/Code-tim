# WebGL Heart

Just a small toy project. Nothing special here.

**Demo 1:** https://snowflk.github.io/webgl-heart/

**Demo 2:** https://snowflk.github.io/webgl-heart/staticpoints/

Three.js setup inspired by https://codepen.io/prisoner849
